"""
trader_peter_v10.py
===================
HFT Market Maker for IMC Prosperity Round 1.
Products: INTARIAN_PEPPER_ROOT, ASH_COATED_OSMIUM

Strategy:
  - EMA(20) of weighted mid-price as Fair Value
  - Competitive quoting: Best Bid+1 / Best Ask-1
  - Minimum edge of 1.0 vs Fair Value (no adverse fills)
  - Linear inventory leaning (elastic band) toward zero
  - Osmium: velocity-based spread widening + informed trader detection
  - Full state persistence via trader_data JSON
"""

import json
from typing import Any, Dict, List
from datamodel import Order, OrderDepth, TradingState, Symbol, Trade


# ─────────────────────────────────────────
#  Config
# ─────────────────────────────────────────
PRODUCTS = ["INTARIAN_PEPPER_ROOT", "ASH_COATED_OSMIUM"]

CONFIG = {
    "INTARIAN_PEPPER_ROOT": {
        "limit":          80,
        "ema_period":     20,
        "base_edge":      1.0,   # min ticks from EMA to quote
        "leaning_factor": 0.05,  # ticks per unit of position
    },
    "ASH_COATED_OSMIUM": {
        "limit":             80,
        "ema_period":        20,
        "base_edge":         1.0,
        "leaning_factor":    0.1,
        "velocity_threshold":0.5,   # EMA delta that triggers extra edge
        "velocity_edge_add": 1.5,   # extra ticks when velocity too high
        "pattern_window":    30,    # how many recent trade sizes to track
        "pattern_threshold": 4,     # repeat count to flag "informed" size
    },
}


# ─────────────────────────────────────────
#  Logger (stdout for Prosperity visualiser)
# ─────────────────────────────────────────
class Logger:
    def __init__(self) -> None:
        self.logs = ""

    def print(self, *objects: Any, sep: str = " ", end: str = "\n") -> None:
        self.logs += sep.join(map(str, objects)) + end

    def flush(
        self,
        state: TradingState,
        orders: Dict[Symbol, List[Order]],
        conversions: int,
        trader_data: str,
    ) -> None:
        print(self.logs, end="")
        self.logs = ""


logger = Logger()


# ─────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────
def weighted_mid(depth: OrderDepth) -> float | None:
    """Volume-weighted mid price. Better than naive (bid+ask)/2."""
    if not depth.buy_orders or not depth.sell_orders:
        return None
    best_bid = max(depth.buy_orders)
    best_ask = min(depth.sell_orders)
    bid_vol = abs(depth.buy_orders[best_bid])
    ask_vol = abs(depth.sell_orders[best_ask])
    total = bid_vol + ask_vol
    if total == 0:
        return (best_bid + best_ask) / 2
    return (best_bid * ask_vol + best_ask * bid_vol) / total


def ema_update(prev_ema: float, price: float, period: int) -> float:
    k = 2 / (period + 1)
    return price * k + prev_ema * (1 - k)


# ─────────────────────────────────────────
#  Trader
# ─────────────────────────────────────────
class Trader:
    """
    Peter V10 — EMA Fair Value Market Maker
    ----------------------------------------
    Smooth PnL via tight competitive quoting + elastic-band inventory control.
    """

    def run(self, state: TradingState):
        # ── Load persisted state ──────────────────────────────────────────
        try:
            saved: dict = json.loads(state.traderData) if state.traderData else {}
        except Exception:
            saved = {}

        ema_map: dict      = saved.get("ema", {})        # product → last EMA
        prev_pos: dict     = saved.get("prev_pos", {})   # for PnL delta log
        osmium_sizes: list = saved.get("osmium_sizes", [])  # recent trade size buffer

        result: Dict[str, List[Order]] = {}

        for product in PRODUCTS:
            if product not in state.order_depths:
                continue

            cfg   = CONFIG[product]
            depth = state.order_depths[product]
            pos   = state.position.get(product, 0)
            limit = cfg["limit"]

            # ── Weighted mid / EMA ────────────────────────────────────────
            wm = weighted_mid(depth)
            if wm is None:
                logger.print(f"[{state.timestamp}] {product}: empty book — skip")
                continue

            prev_ema = ema_map.get(product)
            if prev_ema is None:
                ema = wm  # seed on first tick
            else:
                ema = ema_update(prev_ema, wm, cfg["ema_period"])
            ema_map[product] = ema

            # ── Best bid / ask ────────────────────────────────────────────
            best_bid = max(depth.buy_orders)
            best_ask = min(depth.sell_orders)

            # ── Required edge (Osmium gets velocity + pattern bonus) ──────
            required_edge = cfg["base_edge"]

            if product == "ASH_COATED_OSMIUM":
                velocity      = abs(ema - prev_ema) if prev_ema is not None else 0.0
                velocity_high = velocity >= cfg["velocity_threshold"]
                if velocity_high:
                    required_edge += cfg["velocity_edge_add"]

                # Update recent trade sizes buffer
                trades: List[Trade] = state.market_trades.get(product, [])
                for t in trades:
                    osmium_sizes.append(abs(t.quantity))
                osmium_sizes = osmium_sizes[-cfg["pattern_window"]:]  # cap window

                # Count repeated sizes → detect informed traders
                from collections import Counter
                size_counts = Counter(osmium_sizes)
                informed_sizes = {sz for sz, cnt in size_counts.items()
                                  if cnt >= cfg["pattern_threshold"]}
                if informed_sizes:
                    # Widen edge further — informed flow is dangerous
                    required_edge += 1.0
                    logger.print(
                        f"[{state.timestamp}] {product}: INFORMED TRADER detected "
                        f"sizes={informed_sizes} — edge widened to {required_edge:.1f}"
                    )

            # ── Inventory leaning adjustment ──────────────────────────────
            lean = cfg["leaning_factor"] * pos
            # Positive pos → lower both bid & ask → encourages sells

            # Corrected: inventory leaning shifts the entire quote DOWN
            # when long (making the ask more competitive to sell) and UP
            # when short.
            adj_bid = ema - required_edge - lean
            adj_ask = ema + required_edge - lean

            # ── Competitive quoting: tighten toward best market prices ────
            # We want to be AT MOST 1 tick inside best bid/ask, but only
            # if that's still at or below our EMA-derived adj price.
            bid_price  = min(best_bid + 1, int(adj_bid))
            ask_price  = max(best_ask - 1, int(adj_ask))

            # Guard: bid must be strictly below ask
            if bid_price >= ask_price:
                bid_price = ask_price - 1

            # ── Position capacity ─────────────────────────────────────────
            buy_cap  = limit - pos
            sell_cap = limit + pos

            orders: List[Order] = []
            if buy_cap > 0:
                orders.append(Order(product, int(bid_price),  buy_cap))
            if sell_cap > 0:
                orders.append(Order(product, int(ask_price), -sell_cap))

            result[product] = orders

            # ── Log row ───────────────────────────────────────────────────
            prev  = prev_pos.get(product, 0)
            delta = pos - prev
            logger.print(
                f"[{state.timestamp}] {product} | "
                f"wMid={wm:.2f} EMA={ema:.2f} | "
                f"pos={pos:+d} Δ{delta:+d} | "
                f"bid={bid_price} ask={ask_price} edge={required_edge:.1f} lean={lean:.2f}"
            )
            prev_pos[product] = pos

        # ── Persist state ─────────────────────────────────────────────────
        new_state = json.dumps({
            "ema":          ema_map,
            "prev_pos":     prev_pos,
            "osmium_sizes": osmium_sizes,
        })

        logger.flush(state, result, 0, new_state)
        return result, 0, new_state